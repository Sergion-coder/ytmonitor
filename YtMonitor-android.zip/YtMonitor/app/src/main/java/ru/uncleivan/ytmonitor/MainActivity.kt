package ru.uncleivan.ytmonitor

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// ---------- Модель и хранение ----------

data class Res(val ts: Long, val label: String, val net: String, val lat: Int?, val mbps: Double) {
    fun line() = "$label: " + if (lat == null) "нет связи"
    else "пинг $lat мс, ${"%.1f".format(mbps)} Мбит/с — ${verdict(mbps)}"
}

fun verdict(m: Double) = when {
    m >= 25 -> "4K ок"
    m >= 8 -> "1080p ок"
    m >= 4 -> "720p"
    m > 0 -> "тормозит"
    else -> "не работает"
}

fun load(p: SharedPreferences): List<Res> = try {
    val a = JSONArray(p.getString("hist", "[]"))
    (0 until a.length()).map {
        val o = a.getJSONObject(it)
        Res(o.getLong("ts"), o.getString("label"), o.getString("net"),
            if (o.isNull("lat")) null else o.getInt("lat"), o.getDouble("mbps"))
    }
} catch (e: Exception) { emptyList() }

fun save(p: SharedPreferences, l: List<Res>) {
    val a = JSONArray()
    l.takeLast(500).forEach {
        a.put(JSONObject().put("ts", it.ts).put("label", it.label).put("net", it.net)
            .put("lat", it.lat ?: JSONObject.NULL).put("mbps", it.mbps))
    }
    p.edit().putString("hist", a.toString()).apply()
}

// ---------- Замеры ----------

var lastErr = ""

fun netInfo(c: Context): Pair<String, Boolean> {
    val cm = c.getSystemService(ConnectivityManager::class.java)
    val caps = cm.allNetworks.mapNotNull { cm.getNetworkCapabilities(it) }
    val vpn = caps.any { it.hasTransport(NetworkCapabilities.TRANSPORT_VPN) }
    val base = when {
        caps.any { it.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) } -> "Wi-Fi"
        caps.any { it.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) } -> "Моб. сеть"
        else -> "Сеть?"
    }
    return (base + if (vpn) " + VPN" else "") to vpn
}

fun open(u: String, t: Int): HttpURLConnection =
    (URL(u).openConnection() as HttpURLConnection).apply {
        connectTimeout = t; readTimeout = t
        setRequestProperty("User-Agent", "Mozilla/5.0")
        setRequestProperty("Connection", "close")
    }

// Крупный файл с серверов YouTube (плеер ~2 МБ). Если не нашли — качаем картинки с CDN.
fun playerJs(): String? = try {
    val html = open("https://www.youtube.com/", 8000).inputStream.bufferedReader().use { it.readText() }
    Regex("/s/player/\\w+/player_ias\\.vflset/[\\w_]+/base\\.js").find(html)?.value
        ?.let { "https://www.youtube.com$it" }
} catch (e: Exception) { null }

fun speed(): Double {
    val urls = playerJs()?.let { listOf(it) }
        ?: List(12) { "https://i.ytimg.com/vi/aqz-KE-bpKQ/hqdefault.jpg?t=${System.nanoTime()}$it" }
    var bytes = 0L
    val buf = ByteArray(65536)
    val t0 = System.nanoTime()
    for (u in urls) try {
        open(u, 15000).inputStream.use { s ->
            while (System.nanoTime() - t0 < 15_000_000_000L) {
                val n = s.read(buf); if (n < 0) break; bytes += n
            }
        }
    } catch (e: Exception) { }
    val sec = (System.nanoTime() - t0) / 1e9
    return if (bytes > 0 && sec > 0) bytes * 8 / 1e6 / sec else 0.0
}

suspend fun measure(label: String, net: String): Res = withContext(Dispatchers.IO) {
    val ts = mutableListOf<Long>()
    repeat(5) {
        val s = System.nanoTime()
        try {
            val c = open("https://www.youtube.com/generate_204", 8000)
            val code = c.responseCode // любой ответ сервера (даже 404) = связь с YouTube есть
            c.disconnect()
            if (code > 0) ts += (System.nanoTime() - s) / 1_000_000
        } catch (e: Exception) { lastErr = e.javaClass.simpleName + ": " + (e.message ?: "") }
    }
    val lat = ts.sorted().let { if (it.isEmpty()) null else it[it.size / 2].toInt() }
    Res(System.currentTimeMillis(), label, net, lat, if (lat == null) 0.0 else speed())
}

// ---------- Рейтинг ----------

data class Row(val label: String, val net: String, val sp: Double, val lat: Double,
               val ok: Double, val n: Int, val score: Double)

fun median(l: List<Double>) = l.sorted().let { if (it.isEmpty()) 0.0 else it[it.size / 2] }

fun rank(all: List<Res>): List<Row> = all.groupBy { it.label to it.net }.map { (k, v) ->
    val r = v.takeLast(10)
    val sp = median(r.map { it.mbps })
    val lat = r.mapNotNull { it.lat?.toDouble() }.let { if (it.isEmpty()) 9999.0 else median(it) }
    val ok = r.count { it.mbps > 0 } / r.size.toDouble()
    Row(k.first, k.second, sp, lat, ok, r.size, sp / (1 + lat / 500) * ok)
}.sortedByDescending { it.score }

// ---------- Интерфейс ----------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App(applicationContext) }
            }
        }
    }
}

@Composable
fun App(ctx: Context) {
    val prefs = remember { ctx.getSharedPreferences("yt", 0) }
    var label by remember { mutableStateOf(prefs.getString("label", "") ?: "") }
    val results = remember { mutableStateListOf<Res>().apply { addAll(load(prefs)) } }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    val net = netInfo(ctx)
    val scope = rememberCoroutineScope()
    val ranked = rank(results)

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("YouTube монитор", style = MaterialTheme.typography.headlineSmall) }
        item {
            Text("Сеть: ${net.first}")
            if (!net.second) Text("VPN не включён — замер пойдёт напрямую",
                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        item {
            OutlinedTextField(
                value = label,
                onValueChange = { label = it; prefs.edit().putString("label", it).apply() },
                label = { Text("Сервер Дяди Вани, например Нидерланды-1") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Button(
                onClick = {
                    scope.launch {
                        busy = true; status = "Меряю…"
                        val r = measure(label.ifBlank { "без названия" }, net.first)
                        results.add(r); save(prefs, results); status = r.line() + (if (r.lat == null && lastErr.isNotEmpty()) "\n$lastErr" else ""); busy = false
                    }
                },
                enabled = !busy, modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "Меряю…" else "Замерить") }
        }
        if (status.isNotEmpty()) item { Text(status) }
        if (ranked.isNotEmpty()) {
            item { Text("Рейтинг", style = MaterialTheme.typography.titleMedium) }
            items(ranked) { r ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text((if (r === ranked.first()) "★ " else "") + r.label,
                            fontWeight = FontWeight.Medium)
                        Text("${r.net} · ${verdict(r.sp)}", style = MaterialTheme.typography.bodySmall)
                        Text("${"%.1f".format(r.sp)} Мбит/с · пинг ${r.lat.toInt()} мс · " +
                            "стабильность ${(r.ok * 100).toInt()}% · замеров ${r.n}",
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                TextButton(onClick = { results.clear(); save(prefs, results) }) { Text("Очистить историю") }
            }
        }
    }
}
